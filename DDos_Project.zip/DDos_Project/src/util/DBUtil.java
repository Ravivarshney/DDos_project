package util;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	
	public static Connection getConnection() throws SQLException {
		
		Connection connection=null;
		String user="system";
		String pass ="system";
//		String url="jdbc:oracle:thin:@10.103.47.52:1521:xe";
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String className="oracle.jdbc.driver.OracleDriver";
		
		connection=DriverManager.getConnection(url, user, pass);
		
		
		
		
		return connection;
	}

}
