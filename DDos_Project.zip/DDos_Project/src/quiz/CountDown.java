package quiz;

import javax.swing.JFrame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Date;
public class CountDown extends JFrame {
	public CountDown()
	{
	setLocation(10,10);
	setBackground(new java.awt.Color(44, 62, 80));
	setBounds(10, 10, 100, 100);
setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
   setForeground(new java.awt.Color(255, 255, 255));;
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	final long THIRTY_MINUTES = 3000000;
	final java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("mm : ss");
	final JLabel clock = new JLabel(sdf.format(new Date(THIRTY_MINUTES)),JLabel.CENTER);
	int x = 0;
	ActionListener al = new ActionListener(){
	  long x = THIRTY_MINUTES - 1000;
	  public void actionPerformed(ActionEvent ae){
	    clock.setText(sdf.format(new Date(x)));
	    x -= 1000;}};
	new javax.swing.Timer(1000, al).start();
	JPanel jp = new JPanel();
	jp.add(clock);
	getContentPane().add(jp);
	pack();

	}
}
